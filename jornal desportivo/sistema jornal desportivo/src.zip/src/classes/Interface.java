package classes;

public interface Interface {
  
  public void exibirClassif();

}
